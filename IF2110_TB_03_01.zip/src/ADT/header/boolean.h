/* file : boolean.h */
#ifndef boolean_h
#define boolean_h

#define true 1
#define false 0
#define boolean unsigned char
#endif
