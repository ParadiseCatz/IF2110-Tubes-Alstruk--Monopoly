#ifndef READER_H
#define READER_H
#include "../header/kata.h"
#include "../../globalvariable.h"
void read_with_limit(int mins, int maks, int * in);
void read_user_input(UserAction *userAction, Kata *parameter);
#endif
