#include "../header/cards.h"

int main(){
	InfoKartu C;
	ArrayOfCards Card;

	return 0;
}